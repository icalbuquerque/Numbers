#ifndef _MULTI_H
#define _MULTI_H
#include<stdio.h>

int multi( int numero );

#endif
