#include "multi.h"

int multi( int numero )
{
  int resultado;
  int calc;

  for ( calc = 1; calc <= 10; calc++ )
    {
      resultado = numero * calc;
      printf( "%d x %2d = %3d\n", numero, calc, resultado );
    }

}
