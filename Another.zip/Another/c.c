#include<stdio.h>
#include"multi.h"

main()
{
  int num;

  printf( "Digite um Numero:\n" );
  scanf ( "%d", &num );

  multi( num ); // essa funcao faz a multiplicacao para tabuada
  
}
